document.addEventListener("DOMContentLoaded", function () {
  console.log("DOM is ready");
});
